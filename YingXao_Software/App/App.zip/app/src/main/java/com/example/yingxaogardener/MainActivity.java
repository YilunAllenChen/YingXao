package com.example.yingxaogardener;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    private Button logout;
    private EditText edit;
    private Button add;
    private TextView humidity;
    private TextView moisture;
    private TextView sunlight;
    private TextView temperature;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        logout = findViewById(R.id.logoutButton);
        edit = findViewById(R.id.PlantType);
        add = findViewById(R.id.plantTypeButton);
        humidity = findViewById(R.id.humidity);
        moisture = findViewById(R.id.moisture);
        sunlight = findViewById(R.id.sunlight);
        temperature = findViewById(R.id.temperature);

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Toast.makeText(MainActivity.this, "Logged Out", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(MainActivity.this, StartActivity.class));
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String txt_name = edit.getText().toString();
                if (txt_name.isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter a plant type", Toast.LENGTH_SHORT).show();
                } else {
                    FirebaseDatabase.getInstance().getReference().child("automated-gardener-default-rtdb").child("realtime-plant-value").child("user1").child("plantType").setValue(txt_name);
                }
            }
        });

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("automated-gardener-default-rtdb").child("realtime-plant-value").child("user1");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                humidity.setText(snapshot.child("humidity").getValue().toString());
                moisture.setText(snapshot.child("moisture").getValue().toString());
                sunlight.setText(snapshot.child("uv light intensity").getValue().toString());
                temperature.setText(snapshot.child("temperature in Celsius").getValue().toString());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }
}